compilieren mit
javac -cp "<Pfad zum Ordner Jama oder leer lassen wenn im gleichen Verzeichnis>" HillsCipher.java

Ausf�hren mit java HillsCipher
Geben Sie Parameter entsprechend der usage-Aufforderung an!